# Connect4-Python
Connect 4 programmed in python using pygame.

Video walkthrough on programming this game: https://youtu.be/UYgyRArKDEs

Video walkthrough on programming the AI: https://youtu.be/MMLtza3CZFM
